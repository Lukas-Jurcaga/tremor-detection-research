import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from preprocess import st_sensor_data
from preprocess import st_sensor_rawdata_process
from preprocess import data_shift

data1_gyr = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor Detection\8.Data\RawData20231206\Datasets "
             r"- First tremor assessment\Sadeque\20231206_112138_Gyroscope.csv")
data1_acc = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor Detection\8.Data\RawData20231206\Datasets "
             r"- First tremor assessment\Sadeque\20231206_112138_Acceleration.csv")

data2_gyr = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
             r"Detection\8.Data\RawData20231206\Datasets - First tremor "
             r"assessment\Tiantao\20231206_115916_Gyroscope.csv")

data2_acc = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
             r"Detection\8.Data\RawData20231206\Datasets - First tremor "
             r"assessment\Tiantao\20231206_115916_Acceleration.csv")

data3_gyro = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
              r"Detection\8.Data\RawData20231206\Datasets - First tremor "
              r"assessment\Abdullah\20231206_114621_Gyroscope.csv")

data3_acc = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
             r"Detection\8.Data\RawData20231206\Datasets - First tremor "
             r"assessment\Abdullah\20231206_114621_Acceleration.csv")

data4_gyro = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
              r"Detection\8.Data\RawData20231206\Datasets - First tremor "
              r"assessment\Encarna\20231206_113808_Gyroscope.csv")

data4_acc = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
             r"Detection\8.Data\RawData20231206\Datasets - First tremor "
             r"assessment\Encarna\20231206_113808_Acceleration.csv")

data5_gyr = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
             r"Detection\8.Data\RawData20231206\Datasets - First tremor "
             r"assessment\Faezeh\20231206_112903_Gyroscope.csv")
data5_acc = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
             r"Detection\8.Data\RawData20231206\Datasets - First tremor "
             r"assessment\Faezeh\20231206_112903_Acceleration.csv")

data6_gyr = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
             r"Detection\8.Data\RawData20231206\Datasets - First tremor "
             r"assessment\Marta\20231208_150416_Gyroscope.csv")
data6_acc = (r"D:\Software\OneDrive - Heriot-Watt University\WorkDoc\Tremor "
             r"Detection\8.Data\RawData20231206\Datasets - First tremor "
             r"assessment\Marta\20231208_150416_Acceleration.csv")
data1_label = [[1250, 3000], [3000, 10000],
               [10000, 17700], [21800, 23000],
               [23000, 33000], [33000, 42600]]
data2_label = [[2267, 3934, 5734, 6740, 23334, 24667], [6740, 23334],
               [], [26000, 29334],
               [40000, 45000], [34003, 38667, 45000, 48620]]
data3_label = [[2100, 3150], [3550, 21500],
               [22600, 26650], [38000, 39850, 74400, 79550],
               [40000, 64000, 80600, 98400], [64000, 67500, 98400, 101100]]
data4_label = [[2700, 3150], [3150, 16200],
               [16200, 22125], [30000, 35200, 65700, 67200],
               [35200, 59500], [59500, 65700]]
data5_label = [[0, 200], [200, 11700],
               [11800, 16800], [24300, 24900, 34200, 35600],
               [25000, 32000, 36000, 43500], [43500, 47500]]
data6_label = [[600, 1300], [3000, 5150],
               [1425, 2600, 5150, 7100], [24500, 28500],
               [30000, 32000], [28500, 29500, 32600, 34000]]

files = [[data1_acc, data2_acc, data3_acc, data4_acc, data5_acc, data6_acc],
         [data1_gyr, data2_gyr, data3_gyro, data4_gyro, data5_gyr, data6_gyr]]
labels = [data1_label, data2_label, data3_label, data4_label, data5_label, data6_label]
for index in range(6):
    acc_raw_data = st_sensor_rawdata_process(files[0][index], 208)
    gyr_raw_data = st_sensor_rawdata_process(files[1][index], 208)
    new_acc_columns = {"NodeTime": "Acc_NodeTime", "X": "Acc_X", "Y": "Acc_Y", "Z": "Acc_Z",
                       "NewNodetime": "Acc_NewNodeTime"}
    acc_raw_data = acc_raw_data.rename(columns=new_acc_columns)
    new_gyro_columns = {"NodeTime": "Gyr_NodeTime", "X": "Gyr_X", "Y": "Gyr_Y", "Z": "Gyr_Z",
                        "NewNodetime": "Gyr_NewNodeTime"}
    gyr_raw_data = gyr_raw_data.rename(columns=new_gyro_columns)

    raw_data = pd.concat([acc_raw_data, gyr_raw_data], axis=1)
    # fre = abs(np.fft.fft(raw_data[30000:40000-1].Z))
    # # raw_data[0:1000].plot(x='NodeTime', y='Z', kind='line')
    # fre[0] = 0
    # fre = fre[0:(int)(np.size(fre)/2)]
    # fre_x = np.arange(0,104,104/fre.size)
    # max_index = np.argmax(fre)
    # max_frequency = fre_x[max_index]
    # print(max_frequency)
    # print("Hz")
    # plt.plot(fre_x,fre)
    # plt.show()
    #

    raw_data = raw_data.drop(labels=['Acc_NodeTime'], axis=1)
    raw_data = raw_data.drop(labels=['Gyr_NodeTime'], axis=1)
    raw_data = raw_data.drop(labels=['Acc_NewNodeTime'], axis=1)
    raw_data['Time(s)'] = raw_data['Gyr_NewNodeTime'] * 1 / 200
    raw_data = raw_data.reset_index()
    raw_data = raw_data.drop(labels=['index'], axis=1)
    label = labels[index]

    chosen_label = 5  # choose the label
    datasize = 200  # choose the data size
    step_size = 1  # choose step size

    data_sets = data_shift(label[chosen_label], raw_data, datasize, step_size)
    # raw_data['Label'] = 'None'
    # raw_data['Label'][1250:3000] = 0
    # raw_data['Label'][3000:10000] = 1
    # raw_data['Label'][10000:17700] = 2
    # raw_data['Label'][21800:23000] = 3
    # raw_data['Label'][23000:33000] = 4
    # raw_data['Label'][33000:42600] = 5

    # new_file = r"\Sadeque\20231206_112138_Gyroscope_labeled.csv"
    #
    # raw_data.to_csv(defalut_path + new_file, index=False)
    # raw_data = raw_data.reset_index()
    # plt.plot(raw_data.Z)
    # plt.show()

    # print(raw_data)

    saved_path = r"D:\Work_Doc\conference data test"
    for i, df in enumerate(data_sets):
        df.to_csv(saved_path + f'\order_{index}_dataframe_{i}.csv', index=False)
