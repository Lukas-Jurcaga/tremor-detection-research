import pandas as pd
import numpy as np


def st_sensor_data(csv_path, frequency):
    col_names = ["NodeName", "HostTime", "Date", "NodeTime", "RawData", "X", "Y", "Z"]
    raw_data = pd.read_csv(csv_path, names=col_names)
    raw_data = raw_data.drop(labels=[0, 1, 2])
    raw_data = raw_data.drop(columns=["Date", "HostTime", "NodeName", "RawData"])
    raw_data = raw_data.apply(pd.to_numeric, errors='ignore')
    raw_data = raw_data.sort_values(by=["NodeTime"])
    raw_data = raw_data.reset_index()
    raw_data['NodeTime'] = raw_data['NodeTime'].subtract(raw_data[0:1].NodeTime, fill_value=raw_data[0:1].NodeTime)
    time_unit = 1 / frequency
    raw_data['NodeTime'] = raw_data['NodeTime'].multiply(time_unit, fill_value=time_unit)
    if raw_data.duplicated('NodeTime').any():
        raw_data = raw_data.drop_duplicates()
    return raw_data


def st_sensor_rawdata_process(csv_path, frequency):
    col_names = ["OriNodeName", "HostTime", "Date", "NodeTime", "RawData", "X", "Y", "Z"]
    raw_data = pd.read_csv(csv_path, names=col_names)
    raw_data = raw_data.drop(labels=[0, 1, 2])
    temp = raw_data['RawData'].str.replace('[', '')
    temp = temp.str.replace(']', '')
    temp = temp.str.split(' ', expand=True)
    temp = temp.drop(labels=[0], axis=1)
    temp = temp.apply(pd.to_numeric, errors='ignore')
    temp = temp.applymap(lambda a: 256 + a if a < 0 else a)
    nodetime = temp[1] + temp[2] * 256
    mask = nodetime > 65500
    pos = np.flatnonzero(mask)
    if pos.size == 0:
        print("no more 655235")
    else:
        if (pos[-1] - pos[0]) > 60000:
            print("multi dataset pls re programme")
            return
        nodetime1 = nodetime[pos[0]:]
        nodetime0 = nodetime[0:pos[0]]
        for index, value in nodetime1.items():
            if value < 65000:
                nodetime1[index] = value + 65534
        nodetime = pd.concat([nodetime0, nodetime1])
    raw_data['NewNodetime'] = nodetime
    raw_data = raw_data.drop(columns=["Date", "HostTime", "OriNodeName", "RawData", ])
    raw_data = raw_data.apply(pd.to_numeric, errors='ignore')
    raw_data = raw_data.sort_values(by=["NewNodetime"])
    raw_data = raw_data.reset_index()
    raw_data = raw_data.drop(labels=['index'], axis=1)
    # raw_data['NewNodetime'] = raw_data['NewNodetime'].subtract(raw_data[0:1].NodeTime, fill_value=raw_data[0:1].NodeTime)
    # time_unit = 1/frequency
    # raw_data['NewNodetime'] = raw_data['NewNodetime'].multiply(time_unit, fill_value=time_unit)
    if raw_data.duplicated('NewNodetime').any():
        raw_data = raw_data.drop_duplicates()
    return raw_data


# output a data list. the element of list is the sliced raw_data
# label_data is the array of target label: example [2700,2800,2900,2700]. it must be the 2 times. it is for slice raw data
# raw_data is the dataframe including acc gyro and new nodetime. the index must be reset.
# output_data_size, means the number data of slice part. for example, 200hz sampling rate, 200 data is 1s
#shift_size, means the step to move. 1 means increase 1 to slice a new data set.
# not include all data. the last one data will be missed.
def data_shift(label_data, raw_data, output_data_size, shift_size):
    numbersets = int(len(label_data) / 2)
    data_sets = []

    for x in range(numbersets):
        temp = raw_data[label_data[x * 2]:label_data[(x * 2) + 1]]
        if len(temp) < output_data_size:
            print("error mark1")
            return
        ds = int((len(temp) - output_data_size) / shift_size)
        for i in range(ds):
            data_sets.append(temp[(0 + (i * shift_size)):(output_data_size + (i * shift_size))]) # miss the last one data
    return data_sets
